﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace EmployeeDB.Model
{
    public class SelectLists
    {
        //install Microsoft.AspNet.Mvc.Futures
        public SelectList EmployeeList { get; set; }
    }
}
