﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDB.Model
{
    public class AutoComplete
    {
        public string value { get; set; }
        public string lable { get; set; }
        public string desc { get; set; }
    }
}
